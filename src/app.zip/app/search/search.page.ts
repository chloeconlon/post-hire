import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonHeader, IonItem, IonToolbar, IonTitle, IonContent, IonTabs, IonTabBar, IonTabButton, IonIcon, IonLabel } from '@ionic/angular/standalone';
import { Router } from '@angular/router';
import { Observable } from 'rxjs'; // <--- Import Observable

import { NavigationService } from '../services/navigation.service';
import { ViewChild, ElementRef } from '@angular/core';
import { AnimationController } from '@ionic/angular';


import { VendorService, Vendors } from '../services/vendor.service'; // <--- Import Vendor interface too (assuming it's exported there)
import { ChatService } from '../services/chat.service';

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    CommonModule, // Good, this is correctly here for *ngFor and async
    FormsModule,
    IonHeader, IonItem, IonToolbar, IonTitle, IonContent, IonTabs, IonTabBar, IonTabButton, IonIcon, IonLabel
    // Make sure other Ionic components used in the template are also imported here
  ],
})
export class SearchPage implements OnInit {
  @ViewChild('pageElement', { static: true }) pageElement!: ElementRef;

  // --- Declare the property to hold the vendors Observable ---
  // Use '!' if you're sure it will be initialized in ngOnInit
  // Use '| undefined' if it might not be immediately available
  vendors$!: Observable<Vendors[]>; // <--- This will hold the stream of vendors
  // --- End property declaration ---

  constructor(
    private navService: NavigationService,
    private animationCtrl: AnimationController,
    private chatService: ChatService,
    private router: Router
  ) {}

  private vendorService = inject(VendorService); // Service injected

  
  ngOnInit() {
    this.vendors$ = this.vendorService.getVendors(); // <--- Get the observable stream

    this.vendors$.subscribe(vendors => {
      console.log("Vendors from Firestore:", vendors);
    });
    
  }


  goToVendorProfile(vendorId: string) {
    this.router.navigate(['/job-profile', vendorId]);
  }


  async startChat(vendorId: string): Promise<void> {
    try {
      console.log(`Starting chat with vendor: ${vendorId}`);
      // Use the ChatService to get or create a chat with this vendor
      const chatId = await this.chatService.getOrCreateChat(vendorId);
      
      // Navigate to the chat page with the chatId
      this.router.navigate(['/chat', chatId]);
    } catch (error) {
      console.error('Error starting chat:', error);
      // Handle error (show toast notification, etc)
    }
  }
 

  playAnimation() {
    if (!this.pageElement) {
      console.error('Animation Error: Element not found');
      return;
    }

    const animation = this.animationCtrl.create()
      .addElement(this.pageElement.nativeElement)
      .duration(200)
      .fromTo('transform', 'translateX(100%)', 'translateX(0)');

    animation.play();
  }

  goToMessages() {
    this.navService.goToMessages();
  }

  goToSearch() {
    this.navService.goToSearch();
  }

  goToAccount() {
    this.navService.goToAccount();
  }

}
