// src/app/message-list/message-list.page.ts

import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule, AsyncPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { NavigationService } from '../services/navigation.service';
import { ViewChild, ElementRef } from '@angular/core';
import { AnimationController } from '@ionic/angular';

import { Auth } from '@angular/fire/auth';
import { AccountService, UserData } from '../services/account.service';

import { ChatService, Chat, ExtendedChat } from '../services/chat.service';

import { Observable, of } from 'rxjs';
import { switchMap, map } from 'rxjs/operators';

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonTabs, IonTabBar, IonTabButton, IonIcon, IonLabel, IonList, IonItem, IonAvatar } from '@ionic/angular/standalone';

@Component({
  selector: 'app-message-list',
  templateUrl: './message-list.page.html',
  styleUrls: ['./message-list.page.scss'],
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonItem,
    IonToolbar,
    IonTitle,
    IonContent,
    IonTabs,
    IonTabBar,
    IonTabButton,
    IonIcon,
    IonLabel,
    IonList,
    IonItem,
    IonAvatar,
    AsyncPipe
  ],
})
export class MessageListPage implements OnInit, OnDestroy {
  @ViewChild('pageElement', { static: true }) pageElement!: ElementRef;

  // Update the type to ExtendedChat
  userChats$!: Observable<ExtendedChat[]>;

  constructor(
    private navService: NavigationService,
    private animationCtrl: AnimationController,
    private chatService: ChatService,
    private router: Router,
    private auth: Auth,
    private accountService: AccountService
  ) {
    console.log('MessageListPage constructor');
  }

  ngOnInit() {
    console.log('MessageListPage ngOnInit');
    this.userChats$ = this.chatService.getUserChats();
  }

  ngOnDestroy() {
    console.log('MessageListPage ngOnDestroy');
  }

  openChat(chatId: string) {
    console.log(`Opening chat with ID: ${chatId}`);
    this.router.navigate(['/chat', chatId]);
  }

  // Updated method to properly use ExtendedChat properties
  getOtherParticipantDetails(chat: ExtendedChat): Observable<UserData | null> {
    // If we already have the name from ExtendedChat, use it directly
    if (chat.otherParticipantName && chat.otherParticipantId) {
      return of({
        uid: chat.otherParticipantId,
        name: chat.otherParticipantName
      } as UserData);
    }
    
    // Otherwise fall back to the original logic
    const currentUser = this.auth.currentUser;
    if (!currentUser) {
      return of(null);
    }

    const otherParticipantId = chat.participantIds.find(uid => uid !== currentUser.uid);
    if (!otherParticipantId) {
      console.warn(`Could not find other participant ID in chat ${chat.id}`);
      return of(null);
    }

    // Check if we have participant names in the chat object
    if (chat.participantNames && chat.participantNames[otherParticipantId]) {
      return of({
        uid: otherParticipantId,
        name: chat.participantNames[otherParticipantId]
      } as UserData);
    }

    // As a last resort, try to get the name from the accountService
    console.log(`Fetching details for participant: ${otherParticipantId}`);
    
    // Use the chatService's getUserNameById as a fallback
    return this.chatService.getUserNameById(otherParticipantId).pipe(
      map(name => {
        if (name) {
          return {
            uid: otherParticipantId,
            name: name
          } as UserData;
        }
        return null;
      })
    );
  }

  playAnimation() {
    if (!this.pageElement) {
      console.error('Animation Error: Element not found');
      return;
    }

    const animation = this.animationCtrl.create()
      .addElement(this.pageElement.nativeElement)
      .duration(200)
      .fromTo('transform', 'translateX(100%)', 'translateX(0)');

    animation.play();
  }

  goToMessages() { this.navService.goToMessages(); }
  goToSearch() { this.navService.goToSearch(); }
  goToAccount() { this.navService.goToAccount(); }
}