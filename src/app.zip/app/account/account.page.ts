// src/app/account/account.page.ts

import { Component, OnInit, OnDestroy } from '@angular/core'; // Import OnDestroy
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
// Import the AsyncPipe needed for template if not already in CommonModule or standalone config
import { AsyncPipe } from '@angular/common'; // <-- Import AsyncPipe here

// ... other Ionic imports
import { IonHeader, IonItem, IonToolbar, IonTitle, IonContent, IonTabs, IonTabBar, IonTabButton, IonIcon, IonLabel } from '@ionic/angular/standalone';
// ... other imports

import { Router } from '@angular/router'; // Assuming you might need this for navigation

import { NavigationService } from '../services/navigation.service';
import { ViewChild, ElementRef } from '@angular/core';
import { AnimationController } from '@ionic/angular';
import { Auth } from '@angular/fire/auth'; // Only need Auth if you handle logout here

// Import the AccountService and the interfaces from your service file
import { AccountService, UserAccountData } from '../services/account.service';


import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Observable } from 'rxjs'; // Import Observable


@Component({
  selector: 'app-account',
  templateUrl: './account.page.html',
  styleUrls: ['./account.page.scss'],
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  // Add AsyncPipe to your imports array if it's not covered by CommonModule in standalone
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonItem,
    IonToolbar,
    IonTitle,
    IonContent,
    IonTabs,
    IonTabBar,
    IonTabButton,
    IonIcon,
    IonLabel,
    AsyncPipe // <-- Make sure AsyncPipe is imported and listed here
  ],
})
export class AccountPage implements OnInit, OnDestroy { // Implement OnDestroy

  @ViewChild('pageElement', { static: true }) pageElement!: ElementRef;

  // Declare the public observable from the service
  // Use the combined data interface for convenience in the template
  readonly combinedAccountData$: Observable<UserAccountData | null>;


  // We no longer need separate observables or manual subscriptions
  // private userData$: Observable<UserData | null>; // Remove
  // private vendorData$: Observable<VendorData | null>; // Remove
  // private user$: Observable<User | null>; // Remove
  // private authSubscription: Subscription | null = null; // Remove
  // private userSubscription: Subscription | null = null; // Remove


  constructor(
    // Inject the AccountService (use lowercase for the instance name)
    private accountService: AccountService,
    private auth: Auth, // Keep Auth if you have the logout method here
    private navService: NavigationService,
    private animationCtrl: AnimationController,
    private router: Router // Assuming you might need this for redirects etc.
  ) {
    console.log('AccountPage constructor');

    // Assign the public observable from the service to the component's property
    // The service is responsible for fetching the data based on auth state
    this.combinedAccountData$ = this.accountService.combinedAccountData$;

    // No manual subscriptions needed here as the async pipe will handle it
    // and the service handles the data fetching based on auth state changes.
  }

  ngOnInit() {
    console.log('AccountPage ngOnInit');
    // If you needed to trigger something *imperatively* based on the *first* data load,
    // you *could* subscribe here temporarily and unsubscribe immediately, or use take(1).
    // But for displaying data, the async pipe is sufficient and preferred.

    // Example: Play animation after data *might* load (less ideal, better after render)
    // You might play this animation based on Ionic lifecycle events or other triggers.
    // this.playAnimation();
  }

  ngOnDestroy() {
    console.log('AccountPage ngOnDestroy');
    // No manual subscriptions in this component means nothing to unsubscribe here!
    // The async pipe handles its own cleanup.
  }

  async logout() {
    try {
      await this.auth.signOut();
      console.log('Logged out');
      // Optional: Redirect after logout
      this.goToLogin();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  }

  // --- Your existing navigation and animation methods ---

  playAnimation() {
    if (!this.pageElement) {
      console.error('Animation Error: Element not found');
      return;
    }

    const animation = this.animationCtrl.create()
      .addElement(this.pageElement.nativeElement)
      .duration(200)
      .fromTo('transform', 'translateX(100%)', 'translateX(0)');

    animation.play();
  }

  goToMessages() {
    this.navService.goToMessages();
  }

  goToSearch() {
    this.navService.goToSearch();
  }

  goToAccount() {
    this.navService.goToAccount();
  }

  goToLogin() {
    this.navService.goToLogin();
  }

}
