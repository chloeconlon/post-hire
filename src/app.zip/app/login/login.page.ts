import { Component, inject, OnInit } from '@angular/core'; // Import OnInit
import { CommonModule } from '@angular/common';
import { IonicModule, AlertController, LoadingController } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Auth, createUserWithEmailAndPassword, UserCredential, signInWithEmailAndPassword } from '@angular/fire/auth';
import { Router } from '@angular/router';
import { Firestore, doc, setDoc, collection } from '@angular/fire/firestore';
import { getFirestore, updateDoc } from 'firebase/firestore';

import { NavigationService } from '../services/navigation.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, IonicModule, FormsModule, ReactiveFormsModule],
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
// Implement OnInit
export class LoginPage implements OnInit {

  // Declare Form Groups, but initialize in ngOnInit
  loginForm!: FormGroup; // Use definite assignment assertion '!' or initialize to null/undefined
  customerSignupForm!: FormGroup;
  vendorSignupForm!: FormGroup;

  currentForm: 'login' | 'Customer Signup' | 'Vendor Signup' = 'login';

  

  private readonly auth: Auth = inject(Auth);
  private readonly firestore: Firestore = inject(Firestore);
  private readonly router: Router = inject(Router);
  private readonly alertController: AlertController = inject(AlertController);
  private readonly loadingController: LoadingController = inject(LoadingController);
  private readonly fb: FormBuilder = inject(FormBuilder);

  constructor() {
    // Constructor is primarily for dependency injection
    // Forms are initialized in ngOnInit
  }

  // Implement the ngOnInit lifecycle hook
  ngOnInit() {
    console.log('LoginPage OnInit');
    // Initialize the form groups here
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });

    this.customerSignupForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phoneNo: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      profilePicture: ['', Validators.required] 
    });

    this.vendorSignupForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      name: ['', Validators.required],
      availability: ['', Validators.required],
      bio: ['', Validators.required],
      experience: [null, [Validators.required, Validators.min(0)]],
      jobField: ['', Validators.required],
      phoneNo: ['', Validators.required],
      businessName: ['', Validators.required],
      profilePicture: ['', [Validators.required]],
      rate: [null, [Validators.required, Validators.min(0)]],
      serviceArea: ['', Validators.required],
      jobPosition: ['', Validators.required],
    });
  }


  // --- Your login, customerSignup, and vendorSignup methods go here ---
  // (Paste the full methods from the previous response - they don't need changes)


  async login() {
    if (this.loginForm.invalid) {
      console.log('Login form is invalid.');
      this.displayAlert('Validation Error', 'Please enter a valid email and password.');
      return;
    }

    const loading = await this.loadingController.create({
      message: 'Logging in...',
    });
    await loading.present();

    const { email, password } = this.loginForm.value;

    try {
      const userCredential: UserCredential = await signInWithEmailAndPassword(
        this.auth,
        email,
        password
      );

      const user = userCredential.user;
      console.log('User logged in successfully! UID:', user.uid);

      await this.router.navigate(['/search']);

      this.loginForm.reset();

    } catch (error: any) {
      console.error('Login failed:', error);
      let errorMessage = 'Login failed. Please try again.';

      if (error.code) {
        switch (error.code) {
          case 'auth/invalid-email':
            errorMessage = 'Invalid email format.';
            break;
          case 'auth/user-disabled':
            errorMessage = 'This user account has been disabled.';
            break;
          case 'auth/user-not-found':
            errorMessage = 'No user found with this email.';
            break;
          case 'auth/wrong-password':
            errorMessage = 'Incorrect password.';
            break;
          case 'auth/invalid-credential':
            errorMessage = 'Invalid email or password.';
            break;
          default:
            errorMessage = `Login failed: ${error.message}`;
            break;
        }
      }

      this.displayAlert('Login Failed', errorMessage);

    } finally {
      loading.dismiss();
    }
  }



  onFileSelected(event: any) {
    const file: File = event.target.files[0];
  
    if (!file) return;
  
    const formData = new FormData();
    formData.append('file', file);
    formData.append('upload_preset', 'profile_pictures');
  
    fetch('https://api.cloudinary.com/v1_1/dcksnoj39/image/upload', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      console.log('Image uploaded to Cloudinary:', data.secure_url);
      console.log('Image URL:', data.secure_url); // 👈 This is the image's public link
      this.vendorSignupForm.patchValue({ profilePicture: data.secure_url });
      this.customerSignupForm.patchValue({ profilePicture: data.secure_url });

      this.saveImageUrlToFirestore(data.secure_url); // Optional
    })
    .catch(err => {
      console.error('Image upload error:', err);
    });
  }
  
  

  saveImageUrlToFirestore(imageUrl: string) {
    const userId = this.auth.currentUser?.uid;
    if (!userId) return;

    
  
    const userRef = doc(this.firestore, 'users', userId);
    updateDoc(userRef, { profilePicture: imageUrl });
    
  }
  


  async customerSignup() {
    if (this.customerSignupForm.invalid) {
      console.log('Customer signup form is invalid.');
      this.displayAlert('Validation Error', 'Please fill out all required fields correctly.');
      return;
    }

    const loading = await this.loadingController.create({
      message: 'Signing up customer...',
    });
    await loading.present();


    const {
      name,
      email,
      phoneNo,
      password,
      profilePicture
    } = this.customerSignupForm.value;
    

    

    try {
      const userCredential: UserCredential = await createUserWithEmailAndPassword(
        this.auth,
        email,
        password
      );

      const userId = userCredential.user.uid;
      console.log('Firebase Auth Vendor User Created! UID:', userId);

      const usersCollection = collection(this.firestore, 'users');
      const userDocRef = doc(usersCollection, userId);

      const basicUserData = {
        uid: userId,
        email: email,
        name: name, // You might want to include name here tooS
        accountType: 'vendor',
        phoneNo: phoneNo, // Mark them as a vendor type
        profilePicture: profilePicture, // 👈 ADD THIS LINE
        createdAt: new Date(),
        // Add any other fields common to all users if needed
      };

      await setDoc(userDocRef, basicUserData);
      console.log(`Basic user data saved to Firestore 'users' collection for user ${userId}`);

      console.log('Firebase Auth Customer User Created! UID:', userId);

      const customersCollection = collection(this.firestore, 'users');
      const customerDocRef = doc(customersCollection, userId);

      const customerProfileData = {
        uid: userId,
        email,
        name,
        accountType: 'customer',
        phoneNo,
        profilePicture, // 👈 Include this
        createdAt: new Date()
      };

      await setDoc(customerDocRef, customerProfileData);

      console.log(`Customer profile data saved to Firestore for user ${userId}`);

      this.displayAlert('Signup Successful', 'Your customer account has been created!');
      await this.router.navigate(['/search']);

      this.customerSignupForm.reset();
      this.showLoginForm();

    } catch (error: any) {
      console.error('Customer registration failed:', error);
      let errorMessage = 'Customer registration failed. Please try again.';

      if (error.code) {
        switch (error.code) {
          case 'auth/email-already-in-use':
            errorMessage = 'The email address is already registered.';
            break;
          case 'auth/invalid-email':
            errorMessage = 'Invalid email format.';
            break;
          case 'auth/operation-not-allowed':
            errorMessage = 'Email/Password signup is not enabled. Contact support.';
            break;
          case 'auth/weak-password':
            errorMessage = 'Password is too weak. Please use a stronger password (minimum 6 characters).';
            break;
          default:
            errorMessage = `Registration failed: ${error.message}`;
            break;
        }
      }

      this.displayAlert('Registration Failed', errorMessage);

    } finally {
      loading.dismiss();
    }
  }


  async vendorSignup() {
    if (this.vendorSignupForm.invalid) {
      console.log('Vendor signup form is invalid.');
      this.displayAlert('Validation Error', 'Please fill out all required fields correctly.');
      return;
    }

    const loading = await this.loadingController.create({
      message: 'Signing up vendor...',
    });
    await loading.present();

    if (!this.vendorSignupForm.value.profilePicture) {
      await this.displayAlert('Validation Error', 'Please upload a profile picture.');
      loading.dismiss();
      return;
    }
    

    const {
      email,
      password,
      name,
      availability,
      bio,
      experience,
      jobField,
      phoneNo,
      profilePicture,
      rate,
      serviceArea,
      jobPosition,
      businessName
    } = this.vendorSignupForm.value;

    try {
      const userCredential: UserCredential = await createUserWithEmailAndPassword(
        this.auth,
        email,
        password
      );

      const userId = userCredential.user.uid;
      console.log('Firebase Auth Vendor User Created! UID:', userId);

      const usersCollection = collection(this.firestore, 'users');
      const userDocRef = doc(usersCollection, userId);

      const basicUserData = {
        uid: userId,
        email: email,
        name: name, // You might want to include name here too
        accountType: 'vendor',
        phoneNo: phoneNo, // Mark them as a vendor type
        profilePicture: profilePicture, // 👈 ADD THIS LINE
        createdAt: new Date(),
        // Add any other fields common to all users if needed
      };

      await setDoc(userDocRef, basicUserData);
      console.log(`Basic user data saved to Firestore 'users' collection for user ${userId}`);

      const vendorsCollection = collection(this.firestore, 'vendors');
      const vendorDocRef = doc(vendorsCollection, userId);

      const vendorProfileData = {
        uid: userId,
        email: email,
        name: name,
        accountType: 'vendor',
        availability: availability,
        bio: bio,
        experience: experience,
        jobField: jobField,
        phoneNo: phoneNo,
        profilePicture: profilePicture,
        rate: rate,
        serviceArea: serviceArea,
        businessName: businessName,
        jobPosition: jobPosition,
        createdAt: new Date(),
      };

      await setDoc(vendorDocRef, vendorProfileData);

      console.log(`Vendor profile data saved to Firestore for user ${userId}`);

      this.displayAlert('Signup Successful', 'Your vendor account has been created!');
      await this.router.navigate(['/search']);

      this.vendorSignupForm.reset();
      this.showLoginForm();

    } catch (error: any) {
      console.error('Vendor registration failed:', error);
      let errorMessage = 'Vendor registration failed. Please try again.';

      if (error.code) {
        switch (error.code) {
          case 'auth/email-already-in-use':
            errorMessage = 'The email address is already registered.';
            break;
          case 'auth/invalid-email':
            errorMessage = 'Invalid email format.';
            break;
          case 'auth/operation-not-allowed':
            errorMessage = 'Email/Password signup is not enabled. Contact support.';
            break;
          case 'auth/weak-password':
            errorMessage = 'Password is too weak. Please use a stronger password (minimum 6 characters).';
            break;
          default:
            errorMessage = `Registration failed: ${error.message}`;
            break;
        }
      }

      this.displayAlert('Registration Failed', errorMessage);

    } finally {
      loading.dismiss();
    }
  }

  // Helper method to display Ionic Alerts
  async displayAlert(header: string, message: string) {
    const alert = await this.alertController.create({
      header: header,
      message: message,
      buttons: ['OK'],
    });
    await alert.present();
  }

  // Methods to control which form is visible on the page
  showLoginForm() {
    this.currentForm = 'login';
    this.customerSignupForm.reset();
    this.vendorSignupForm.reset();
  }

  showCustomerSignupForm() {
    this.currentForm = 'Customer Signup';
    this.loginForm.reset();
    this.vendorSignupForm.reset();
  }

  showVendorSignupForm() {
    this.currentForm = 'Vendor Signup';
    this.loginForm.reset();
    this.customerSignupForm.reset();
  }

}
