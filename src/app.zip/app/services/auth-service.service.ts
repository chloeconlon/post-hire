import { Injectable, inject } from '@angular/core';
import { Auth, User, getAuth, onAuthStateChanged, signOut } from 'firebase/auth';
import { Observable, from } from 'rxjs'; // Import Observable and 'from' for convenience

@Injectable({
  providedIn: 'root' // Makes the service a singleton provided at the root level
})
export class AuthService { // Let's call it AuthService

  private auth: Auth = getAuth(); // Get the Firebase Auth instance

  // This is the Observable that other parts of your app will subscribe to.
  // It will emit the current User object when signed in, or null when signed out.
  user$: Observable<User | null>;

  constructor() {
    // Wrap the Firebase onAuthStateChanged listener in an RxJS Observable.
    // The 'from' operator can convert a callback-based API like onAuthStateChanged
    // into an Observable, but it's slightly cleaner to wrap it manually
    // to ensure proper cleanup (unsubscribing the listener).

    this.user$ = new Observable<User | null>(observer => {
      // onAuthStateChanged returns an unsubscribe function. We'll use this
      // in the observer's teardown logic.
      const unsubscribe = onAuthStateChanged(this.auth,
        user => {
          // When the auth state changes, emit the new user (or null)
          observer.next(user);
        },
        error => {
          // If there's an error, pass it to the observer
          observer.error(error);
        }
      );

      // Return the unsubscribe function. RxJS will call this when the
      // Observable is unsubscribed (e.g., when the service is destroyed
      // or a component using the async pipe is removed).
      return () => unsubscribe();
    });

    // Optional: Log the initial state or changes for debugging
    // this.user$.subscribe(user => {
    //   console.log('Auth state changed:', user ? 'Signed in' : 'Signed out', user ? user.uid : null);
    // });

  }

  // Optional: Method to get the *current* user state synchronously.
  // Be careful using this, as it might be null for a brief moment during
  // app initialization even if a user *is* signed in. The user$ observable
  // is generally preferred for reactivity.
  getCurrentUser(): User | null {
    return this.auth.currentUser;
  }

  // Optional: Add a logout method
  async signOut() {
    try {
      await signOut(this.auth);
      console.log('User signed out successfully');
    } catch (error) {
      console.error('Error signing out:', error);
      throw error; // Re-throw the error for the caller to handle
    }
  }

  // You would also add methods for signing in here, like:
  // signInWithEmailAndPassword(email, password) { ... }
  // signInWithGoogle() { ... }
  // createUserWithEmailAndPassword(email, password) { ... }
}
