// src/app/services/account.service.ts (Renamed from user.service.ts for clarity)

import { Injectable } from '@angular/core';
import { Auth, User, authState } from '@angular/fire/auth';
import { Firestore, Timestamp, doc, docData } from '@angular/fire/firestore';
// Remove unnecessary imports for collection, query, where, collectionData
// as we are fetching a single document by ID, not querying a collection.
// import { collection, query, where, CollectionReference } from '@angular/fire/firestore';
// import { collectionData } from '@angular/fire/firestore';

import { Observable, of, combineLatest } from 'rxjs'; // Import combineLatest
import { switchMap, tap, map } from 'rxjs/operators'; // Import tap and map

// Define interfaces for your document data for type safety
export interface UserData {
  uid?: string; // Add uid here, docData({ idField: 'id' }) or similar will add it
  email?: string;
  name?: string;
  accountType?: string; // e.g., 'customer', 'vendor'
  profilePicture?: string;
  createdAt?: Timestamp;
  // Add all other fields from your user document
  // profilePicture?: string; // Example
  // ... more fields from the 'users' doc
}

// Renamed Vendors to VendorData for clarity and consistency with UserData
export interface VendorData {
  uid?: string; // Add uid here, docData({ idField: 'id' }) or similar will add it
  name?: string; // Vendor name
  location?: string;
  availability?: string;
  bio?: string;
  email?: string; // Maybe redundant if same as UserData email?
  experience?: string;
  jobField?: string;
  phoneNo?: string;
  profilePicture?: string; // Vendor profile picture
  rate?: number;
  serviceArea?: string;
  businessName?: string;
  // Add all other expected properties from the 'vendors' doc
  // ... more fields from the 'vendors' doc
}

// Optional interface to combine both sets of data
export interface UserAccountData {
    userData: UserData | null;
    vendorData: VendorData | null;
}


@Injectable({
  // This makes the service a singleton available throughout your app
  providedIn: 'root'
})
export class AccountService {

  // Private observable for the AngularFire Auth state
  private readonly authState$: Observable<User | null>;

  // Public observable for the user's document data from 'users' collection
  readonly userData$: Observable<UserData | null>;

  // Public observable for the user's document data from 'vendors' collection
  // This will emit null if the user is not a vendor (i.e., no doc in 'vendors' collection)
  readonly vendorData$: Observable<VendorData | null>; // Use VendorData, not Vendors

  // Optional: An observable that combines both
  readonly combinedAccountData$: Observable<UserAccountData | null>;


  constructor(private auth: Auth, private firestore: Firestore) {
    console.log('AccountService initialized');

    // Get the AngularFire Auth state observable
    this.authState$ = authState(this.auth);

    // --- Logic for fetching User Data ---
    this.userData$ = this.authState$.pipe(
      tap(user => console.log('Auth state changed:', user ? user.uid : 'Logged out')), // Optional: for debugging
      switchMap(user => {
        if (user) {
          // If user is logged in, get the reference to their document in the 'users' collection
          const userDocRef = doc(this.firestore, 'users', user.uid);
          // Return an observable of the document data.
          // docData({ idField: 'uid' }) is often useful to include the document ID in the data
          return docData(userDocRef, { idField: 'uid' }) as Observable<UserData>;
        } else {
          // If user is logged out, return an observable that emits null
          return of(null);
        }
      }),
      tap(data => console.log('UserData emitted:', data)) // Optional: for debugging
    );

    // --- Logic for fetching Vendor Data ---
    // We use the same authState$ observable so that when the user logs in/out,
    // the service tries to fetch vendor data as well.
    this.vendorData$ = this.authState$.pipe(
      tap(user => console.log('Auth state changed for vendor data fetch:', user ? user.uid : 'Logged out')), // Optional: for debugging
      switchMap(user => {
        if (user) {
          // If user is logged in, get the reference to their document in the 'vendors' collection
          // Crucially, change 'users' to 'vendors' here!
          const vendorDocRef = doc(this.firestore, 'vendors', user.uid);
          // docData will emit the document data if it exists, and null if it doesn't.
          // This is perfect for users who are not vendors – vendorData$ will simply emit null.
           return docData(vendorDocRef, { idField: 'uid' }) as Observable<VendorData>;
        } else {
          // If user is logged out, return an observable that emits null
          return of(null);
        }
      }),
       tap(data => console.log('VendorData emitted:', data)) // Optional: for debugging
    );

    // --- Optional: Combine User and Vendor data ---
    // Use combineLatest to get updates whenever either userData$ or vendorData$ emits.
    // This stream will wait for both source observables to emit at least once.
    this.combinedAccountData$ = combineLatest([this.userData$, this.vendorData$]).pipe(
        map(([userData, vendorData]) => {
            // The map operator receives the latest values from both observables as an array.
            // If userData is null, it implies the user is logged out or their base user doc
            // doesn't exist. In this case, the combined data should probably be null.
            if (!userData) {
                return null;
            }
            // Otherwise, return the combined object. vendorData might still be null here
            // if the user is not a vendor but the user doc exists.
            return { userData, vendorData };
        }),
        tap(data => console.log('Combined Account Data emitted:', data)) // Optional: for debugging
    );

  }

  // You can add methods here to update user or vendor data
  // Components would call these methods to trigger changes in Firestore.
  async updateUserData(uid: string, data: Partial<UserData>): Promise<void> {
    if (!uid) {
        console.error("Cannot update user data: UID is missing.");
        return;
    }
    const userDocRef = doc(this.firestore, 'users', uid);
    // Make sure to import updateDoc from '@angular/fire/firestore'
    // and implement appropriate Firestore Security Rules!
    // Example: await updateDoc(userDocRef, data);
     console.log(`Attempted to update user document for UID: ${uid}`);
     // You would add the actual Firestore update logic here
     // Example: await updateDoc(userDocRef, { name: data.name, accountType: data.accountType });
  }

  async updateVendorData(uid: string, data: Partial<VendorData>): Promise<void> {
     if (!uid) {
        console.error("Cannot update vendor data: UID is missing.");
        return;
    }
    const vendorDocRef = doc(this.firestore, 'vendors', uid);
    // Make sure to import updateDoc from '@angular/fire/firestore'
    // and implement appropriate Firestore Security Rules!
    // Example: await updateDoc(vendorDocRef, data);
    console.log(`Attempted to update vendor document for UID: ${uid}`);
    // You would add the actual Firestore update logic here
    // Example: await updateDoc(vendorDocRef, { businessName: data.businessName, bio: data.bio });
  }

  // You could also add methods to create the vendor document if a user decides to become a vendor
   async createVendorData(uid: string, initialData: VendorData): Promise<void> {
       if (!uid) {
           console.error("Cannot create vendor data: UID is missing.");
           return;
       }
       const vendorDocRef = doc(this.firestore, 'vendors', uid);
       // Use setDoc to create or overwrite the document
       // Make sure to import setDoc from '@angular/fire/firestore'
       // Example: await setDoc(vendorDocRef, initialData, { merge: true }); // Use merge if you might add fields later
       console.log(`Attempted to create/set vendor document for UID: ${uid}`);
        // You would add the actual Firestore set logic here
        // Example: await setDoc(vendorDocRef, { ...initialData, uid: uid }); // Ensure UID is in the doc
   }


  // Optional: You could expose the raw authState$ observable if needed by components
  // getAuthState(): Observable<User | null> {
  //   return this.authState$;
  // }
}
