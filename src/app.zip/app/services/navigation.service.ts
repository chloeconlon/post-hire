import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class NavigationService {
  constructor(private router: Router) {}
  

  goToMessages() {
    this.router.navigate(['/message-list']);
  }

  goToSearch() {
    this.router.navigate(['/search']);
  }

  goToAccount() {
    this.router.navigate(['/account']);
  }

  goToChat() {
    this.router.navigate(['/chat']);
  }

  goToLogin() {
    this.router.navigate(['/login']);

  }
}

