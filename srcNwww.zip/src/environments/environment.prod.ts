export const environment = {
  production: true,
errorHandler: true,
  firebase: {
    apiKey: "AIzaSyDOw3pDySMFgyauAn5im0K3NWh8xvbn5Q4",
    authDomain: "ionic-app-4b586.firebaseapp.com",
    projectId: "ionic-app-4b586",
    storageBucket: "ionic-app-4b586.appspot.com", // FIXED: Correct format for storage bucket
    messagingSenderId: "453454832882",
    appId: "1:453454832882:web:0d2cbed2ee2473f2979c6b",
    measurementId: "G-9K7CWXF4QM"
  }
  
};


