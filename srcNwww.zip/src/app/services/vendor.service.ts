// src/app/services/vendor.service.ts

import { Injectable, inject } from '@angular/core';
import { Firestore, collection, collectionData, doc, docData } from '@angular/fire/firestore';
import { Observable } from 'rxjs';

// --- Define and EXPORT the Vendor interface ---
export interface Vendors {
  id: string; // The document ID
  name: string;
  bio: string;
  email: string;
  experience: string;
  jobField: string;
  phoneNo: string;
  profilePicture: string;
  rate: number;
  businessName: string;
  workDays: string[];
  jobPosition: string;
  serviceArea: string[];
  startTime: string;
  endTime: string;


  // Add all other expected properties here
  // exampleField?: string;
}
// --- End Vendor interface ---

@Injectable({
  providedIn: 'root'
})
export class VendorService {
  private firestore: Firestore = inject(Firestore);

  // --- Use the Vendor interface for typing ---
  getVendors(): Observable<Vendors[]> { // <-- Now returns Observable<Vendor[]>

    const itemCollection = collection(this.firestore, 'vendors');

    // Cast the result to Observable<Vendor[]>
    return collectionData(itemCollection, { idField: 'id' }) as Observable<Vendors[]>;
  }

  // --- Use the Vendor interface for typing ---
  getVendorById(id: string): Observable<Vendors | undefined> { // <-- Returns Observable<Vendor | undefined>
    const vendorDocument = doc(this.firestore, `vendors/${id}`);
    // Cast the result to Observable<Vendor | undefined>
    return docData(vendorDocument, { idField: 'id' }) as Observable<Vendors | undefined>;
  }
}
