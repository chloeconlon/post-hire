import { Injectable } from '@angular/core';
import { PushNotifications } from '@capacitor/push-notifications';
import { PushNotificationSchema } from '@capacitor/push-notifications';




@Injectable({
  providedIn: 'root'
})
export class PushNotificationService {
  constructor() {
    this.initializePushNotifications();
  }

  initializePushNotifications() {
    // Request permission to send push notifications
    PushNotifications.requestPermissions().then(result => {
      if (result.receive === 'granted') {
        PushNotifications.register();
      }
    });

    // Listen for successful registration and retrieve device token
    PushNotifications.addListener('registration', (token) => {
      console.log('Push Registration Success:', token.value);
    });

    // Handle incoming notifications
    PushNotifications.addListener('pushNotificationReceived', (notification) => {
      console.log('Push notification received:', notification);
      this.handleNotification(notification);
    });
  }

  handleNotification(notification: PushNotificationSchema) {
    console.log('Handling notification:', notification);
  }
}