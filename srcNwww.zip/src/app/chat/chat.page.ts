import { Component, OnInit, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonHeader, IonItem, IonToolbar, IonTitle, IonContent, IonTabs, IonTabBar, IonTabButton, IonIcon, IonLabel, IonButtons, IonButton, IonFooter } from '@ionic/angular/standalone';
import { Router } from '@angular/router';

import { NavigationService } from '../services/navigation.service';
import { ViewChild, ElementRef } from '@angular/core';
import { AnimationController, IonContent as IonContentDirective } from '@ionic/angular';

import { ChatService, ChatMessage, ExtendedChat, EnrichedChatMessage } from '../services/chat.service';
import { ActivatedRoute } from '@angular/router';
import { Observable, Subscription, take } from 'rxjs';

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { addIcons } from 'ionicons';
import { camera, arrowBack, send } from 'ionicons/icons';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.page.html',
  styleUrls: ['./chat.page.scss'],
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],  
  imports: [
    FormsModule, 
    CommonModule, 
    IonHeader, 
    IonItem, 
    IonToolbar, 
    IonTitle, 
    IonContent, 
    IonTabs, 
    IonTabBar, 
    IonTabButton, 
    IonIcon, 
    IonLabel,
    IonButtons,
    IonButton,
    IonFooter
  ],
})
export class ChatPage implements OnInit, AfterViewInit {

  @ViewChild('pageElement', { static: true }) pageElement!: ElementRef;
  @ViewChild(IonContentDirective, { static: false }) content!: IonContentDirective;
  @ViewChild('chatContent') chatContent!: ElementRef;

  constructor(
    private navService: NavigationService, 
    private animationCtrl: AnimationController, 
    private chatService: ChatService, 
    private router: Router, 
    private activatedRoute: ActivatedRoute
  ) {
    // Register icons
    addIcons({
      camera,
      arrowBack,
      send
    });
  }

  userChats$!: Observable<ExtendedChat[]>;
  messageSubscription?: Subscription;
  newMessage: string = '';
  vendorId!: string;
  chatId!: string;
  messages$!: Observable<EnrichedChatMessage[]>;
  recipientName: string = '';
  recipientProfilePicture: string = '';
  currentUserId!: string;
  messagesLoaded: boolean = false;

  ngOnInit(): void {
    // Get chat ID from route
    this.chatId = this.activatedRoute.snapshot.paramMap.get('chatId')!;
    console.log("Chat opened with ID:", this.chatId);

    // Get current user's ID
    this.chatService.getAuthState().subscribe(user => {
      if (user) {
        this.currentUserId = user.uid;
 
        // Fetch messages for this chat
        this.messages$ = this.chatService.getChatMessages(this.chatId);
        
        // Subscribe to messages to trigger initial scroll after first data load
        this.messageSubscription = this.messages$.subscribe(messages => {
          console.log("Messages loaded:", messages.length);
          this.messagesLoaded = true;
          
          // Schedule multiple scroll attempts to ensure it works
          this.scrollToBottomMultipleTimes();
        });
 
        this.chatService.getUserChats().subscribe(chats => {
          console.log("User Chats Retrieved:", chats); 
          if (!chats.length) {
            console.warn("No chats found matching the current user's ID.");
          }
        });
        
        // Identify the recipient (other participant in the chat)
        this.chatService.getUserChats().subscribe(chats => {
          const chat = chats.find(c => c.id === this.chatId);
          if (chat) {
            this.recipientName = chat.otherParticipantName || 'Unknown User';
            this.recipientProfilePicture = chat.otherParticipantProfilePicture || 'assets/default-avatar.png';
          } else {
            console.warn('Chat not found');
            this.recipientName = 'Unknown User';
            this.recipientProfilePicture = 'assets/default-avatar.png';
          }
        });
      }
    });
  }
  
  ngAfterViewInit(): void {
    console.log('ngAfterViewInit executed!');
    this.chatId = this.activatedRoute.snapshot.paramMap.get('chatId')!;
    this.vendorId = this.activatedRoute.snapshot.paramMap.get('vendorId')!;
    
    console.log("Chat opened with ID:", this.chatId);
    console.log("Vendor ID:", this.vendorId);
    
    // Try to scroll initially in case we already have the data
    if (this.messagesLoaded) {
      this.scrollToBottomMultipleTimes();
    }
  }

  // Helper method to try multiple scroll attempts with increasing delays
  private scrollToBottomMultipleTimes(): void {
    // Try immediately
    this.scrollToBottom(0);
    
    // Try after short delay
    setTimeout(() => this.scrollToBottom(0), 100);
    
    // Try after medium delay
    setTimeout(() => this.scrollToBottom(0), 500);
    
    // Try after longer delay
    setTimeout(() => this.scrollToBottom(0), 1000);
  }

  async sendMessage() {
    if (!this.newMessage.trim()) return;
    
    if (!this.chatId || !this.currentUserId) {
      console.error("Missing chatId or currentUserId.");
      return;
    }
    
    await this.chatService.sendMessage(this.chatId, this.newMessage);
    this.newMessage = ''; // Clear input
    
    // Multiple scroll attempts after sending a message
    this.scrollToBottomMultipleTimes();
  }
  
  // Method to take a photo using the device camera
  async takePhoto() {
    try {
      // Request camera permissions and take photo
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.Base64,
        source: CameraSource.Camera
      });
      
      if (image && image.base64String) {
        console.log("Photo taken successfully");
        await this.sendPhotoMessage(image.base64String);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
    }
  }
  
  // Method to send the photo as a message
  async sendPhotoMessage(base64Image: string) {
    if (!this.chatId || !this.currentUserId) {
      console.error("Missing chatId or currentUserId.");
      return;
    }
    
    // Send image through the chat service
    await this.chatService.sendImageMessage(this.chatId, base64Image);
    
    // Scroll to bottom after sending
    this.scrollToBottomMultipleTimes();
  }
  
  private scrollToBottom(delay: number = 300): void {
    setTimeout(() => {
      console.log("Attempting to scroll to bottom");
      
      // Use Ionic's built-in method if available
      if (this.content) {
        this.content.scrollToBottom(0);
        console.log("Used IonContent scrollToBottom");
      } 
      // Fallback to direct DOM manipulation
      else if (this.chatContent?.nativeElement) {
        this.chatContent.nativeElement.scrollTop = this.chatContent.nativeElement.scrollHeight;
        console.log("Used direct DOM scrolling");
      }
    }, delay);
  }

  playAnimation() {
    if (!this.pageElement) {
      console.error('Animation Error: Element not found');
      return;
    }

    const animation = this.animationCtrl.create()
      .addElement(this.pageElement.nativeElement)
      .duration(200)
      .fromTo('transform', 'translateX(100%)', 'translateX(0)');

    animation.play();
  }

  goToMessages() {
    this.navService.goToMessages();
  }

  ngOnDestroy(): void {
    // Clean up subscriptions
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
  }
}