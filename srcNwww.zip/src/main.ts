// src/main.ts

import { enableProdMode, Injector, inject } from '@angular/core'; // Import Injector and inject
import { bootstrapApplication } from '@angular/platform-browser';
import { RouteReuseStrategy, provideRouter, withPreloading, PreloadAllModules } from '@angular/router';
import { IonicRouteStrategy, provideIonicAngular } from '@ionic/angular/standalone';

import { environment } from './environments/environment';
import { routes } from './app/app.routes';
import { AppComponent } from './app/app.component';

// --- Import Firebase standalone provider functions ---
// Import FirebaseApp type if you want stricter typing
import { provideFirebaseApp, initializeApp, FirebaseApp } from '@angular/fire/app';
// Import getFirestore and provideFirestore from the firestore package
import { getFirestore, provideFirestore } from '@angular/fire/firestore';
// Import getAuth and provideAuth from the auth package
import { getAuth, provideAuth } from '@angular/fire/auth';


// --- Enable production mode if environment is set to production ---
if (environment.production) {
  enableProdMode();
}

// --- Bootstrap the application with required providers ---
bootstrapApplication(AppComponent, {
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    provideIonicAngular(),
    provideRouter(routes, withPreloading(PreloadAllModules)),

    provideFirebaseApp(() => initializeApp(environment.firebase)),
    provideFirestore(() => getFirestore()),
    provideAuth(() => getAuth()),


  ],
});

// --- IMPORTANT ---
// Double check that you have removed any conflicting manual Firebase
// initialization code (like the contents of that old src/lib/firebase/auth.ts
// file if it was trying to call getAuth() or initializeApp() outside
// of this AngularFire provider chain).
