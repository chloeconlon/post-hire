import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
	"appId": "com.maggiecahill.myjobs",
	"appName": "myJobs",
	"webDir": "www"
  }

export default config;
